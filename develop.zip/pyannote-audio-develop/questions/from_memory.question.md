---
title: "Can I apply pretrained pipelines on audio already loaded in memory?"
alt_titles:
  - "Can I apply models on an audio array?"
---

Yes: read [this tutorial](tutorials/applying_a_pipeline.ipynb) until the end.
