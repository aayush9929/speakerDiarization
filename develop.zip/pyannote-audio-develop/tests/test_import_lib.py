from pyannote.audio.core.model import Model


def test_import_lib():
    """This is a dummy test, just to check
    if the lib can be successfully imported.
    """
    assert Model is not None
